from stack import Stack

class SimpleCalculator:
    def __init__(self):
        """
        Instantiate any data attributes
        """
        self.L= []

    def evaluate_expression(self, input_expression):
        """
        Evaluate the input expression and return the output as a float
        Return a string "Error" if the expression is invalid
        """
        n1, n2,n1c,n2c = 0,0,0,0
        num = ['0','1', '2', '3', '4', '5', '6', '7', '8', '9']
        ops = ['+', '-', '*', '/']
        for i in range(len(input_expression)):
            if input_expression[i]==" ":
                
                continue
            elif input_expression[i] in num:
                n1 = (n1 * 10) + int(input_expression[i])
                n1c+=1
            else:
                k = i
                break
            
        for i in range(k, len(input_expression)):
            if input_expression[i] == " ":
                continue
            elif input_expression[i] in ops:
                op = input_expression[i]
            else:
                n2c+=1
                n2 = (n2*10) + int(input_expression[i])
        
        if (n2 == 0 and n2c==0) or (n1==0 and n1c==0):
            self.L.insert(0,(input_expression, "Error"))
            return "Error"
        else:
            re = 0
            if op == "+":
                re = n1 + n2
            elif op == "-":
                re = n1 - n2
            elif op == "*":
                re = n1 * n2
            elif op == "/":
                re = n1 / n2
        self.L.insert(0,(input_expression, re))
        return re
        

    def get_history(self):
        """
        Return history of expressions evaluated as a list of (expression, output) tuples
        The order is such that the most recently evaluated expression appears first 
        """
        return self.L