

class Stack:
	def __init__(self):
		# Initialise the stack's data attributes
		self.l= []
		
	
	def push(self, item):
		self.l.insert(0, item)
		

	def peek(self):
		# Return the element at the top of the stack
		# Return a string "Error" if stack is empty
		if self.l == []:
			return "Error"
		else:
			return self.l[0]
		

	def pop(self):
		# Pop an item from the stack if non-empty
		if self.l!=[]:
			self.l.pop(0)
		

	def is_empty(self):
		# Return True if stack is empty, False otherwise
		return self.l == []
		

	def __str__(self):
		# Return a string containing elements of current stack in top-to-bottom order, separated by spaces
		# Example, if we push "2" and then "3" to the stack (and don't pop any elements), 
		# then the string returned should be "3 2"
		s=""
		for i in range(len(self.l)):
			if i<(len(self.l)-1):
				s= s + str(self.l[i]) + " "
			else:
				s = s + str(self.l[i])
		return s
		

	def __len__(self):
		return len(self.l)
