from simple_calculator import SimpleCalculator
from stack import Stack

class AdvancedCalculator(SimpleCalculator):
	def __init__(self):
		
		SimpleCalculator.__init__(self)
		self.tokens=[]
		self.l1=Stack()    #opt
		self.l2=Stack()    #opd

	def evaluate_expression(self, input_expression):
		'''
		Evaluate the input expression and return the output as a float
		Return a string "Error" if the expression is invalid
		'''
#		ops = ['+','-','*','/']
#		bracket = ['{','(','}',')']
#		emp = [" "]
		validity=True
		for e in input_expression:
			if (e!='+' and e!='-' and e!='*' and e!='/' and e!=' ' and e!='(' and e!=')' and e!='{' and e!='}'):
				if(ord(e)> 57 or ord(e)< 48):
					validity=False
		if not validity:
			self.L.insert(0,(input_expression,"Error"))
			return "Error"
		self.token=self.tokenize(input_expression)
		if(not self.check_brackets(self.token)):
			self.L.insert(0,(input_expression,"Error"))
			return "Error"
		self.l1.__init__()        #opt
		self.l2.__init__()        #opd
		ans=self.evaluate_list_tokens(self.token)
		self.L.insert(0,(input_expression,ans))
		return ans
		

	def tokenize(self, input_expression):
		'''
		convert the input string expression to tokens, and return this list
		Each token is either an integer operand or a character operator or bracket
		'''
		num = ['0','1','2','3','4','5','6','7','8','9']
		ops = ['+','-','*','/']
		brackets = ['{','(','}',')']
		m=[]
		n=""
		for i in range(len(input_expression)):
			ch=input_expression[i]
			if (ch=='+' or ch=='-' or ch=='*' or ch=='/' or ch=='{' or ch=='}' or ch=='(' or ch==')'):
				if(n!=""):
					m.append(int(n))
				m.append(ch)
				n=""
			elif ch==" ":
				if(n!=""):
					m.append(int(n))
				n=""
			elif ch!=" ":
				n=n+ch
		if(n!=""):
			m.append(int(n))
		return m
				

	def check_brackets(self, list_tokens):
		nom=0
		curl=0
		for i in range(len(list_tokens)):
			n = len(list_tokens)
			if(list_tokens[i]=='('):
				if i <n and list_tokens[i+1]==')':
					return False
				else:
					nom+=1
			elif(list_tokens[i]==')'):
				nom-=1
				if(nom< 0):
					return False
			elif(list_tokens[i]=='{'):
				if i <n and list_tokens[i+1]=='}':
					return False
				else:
					curl+=1
				
			elif(list_tokens[i]=='}'):
				if(nom> 0):
					return False
				curl-=1
				if(curl< 0):
					return False
		if(curl!=0 or nom!=0):
			return False
		return True
		

	def evaluate_list_tokens(self, list_token):
		for token in list_token:
			if (token=='(' or token=='{'):
				self.l1.push(token)
			elif (token==')'):
				while self.l1.peek()!='(':
					rv=self.fun()
					if rv== False:
						return "Error"
				self.l1.pop()
			elif token=='}':
				while self.l1.peek()!='{':
					rv=self.fun()
					if rv==False:
						return "Error"
				self.l1.pop()
			elif (token=='+' or token=='-' or token=='*' or token=='/'):
				while True:
					if self.l1.is_empty():
						break
					if (self.l1.peek()=='(' or self.l1.peek()=='{'):
						break
					if (AdvancedCalculator.operation(token,self.l1.peek())):
						rv=self.fun()
						if rv ==False:
							return "Error"
					else:
						break
				self.l1.push(token)
			else:
				self.l2.push(token)
		while True:
			if self.l1.is_empty():
				break
			rv=self.fun()
			if rv == False:
				return "Error"
		return self.l2.peek()

	def fun(self):    #do_it
		op=self.l1.pop()
		if len(self.l2)< 2:
			return False
		a=int(self.l2.pop())
		b=int(self.l2.pop())
		if op=='+':
			self.l2.push(a+b)
		elif op=='-':
			self.l2.push(b-a)
		elif op=='*':
			self.l2.push(a*b)
		else:
			if(a==0):
				return False
			self.l2.push(float(int(b)/int(a)))
		return True
	def operation(o1,o2):      #lower
		if(o1=='/'):
			if o2=='/':
				return True
			else:
				return False
		elif o1=="*":
			if o2=="*" or o2=="/":
				return True
			else:
				return False
		elif(o1=='+' or o1=='-'):
			return True
	def get_history(self):
		return self.L